INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('1', 'Let Us C', 'Yashavant P. Kanetkar', '200.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('2', 'Thinking In Java', 'Thinking In Java', '300.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('3', 'Computer Networking ', 'James F. Kurose', '250.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('4', 'Head First C#', 'Andrew Stellman', '400.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('5', 'What is HTML5?', 'Brett McLaughlin', '300.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('6', 'HTML5 in Action', 'Joe Lennon', '569.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('7', 'OOP with C++', 'Balagurusamy', '308.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('8', 'C++: The Complete Reference', 'Heabert Schildt ', '532.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('9', 'Head First SQL', 'Lynn Beighley', '450.00');
INSERT INTO `shopping_cart`.`books` (`BOOK_ID`, `BOOK_NAME`, `AUTHOR`, `PRICE`) VALUES ('10', 'SQl: The Complete Reference', 'James Groff', '667.00');


INSERT INTO `shopping_cart`.`order_details` (`ORDER_ID`, `BOOK_ID`, `CUS_NAME`, `PHONE_NO`, `ADDRESS`, `ORDER_DATE`, `QUANTITY`) VALUES ('1', '1', 'Amit', '9673960407', 'Radhika Vihar', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`ORDER_ID`, `BOOK_ID`, `CUS_NAME`, `PHONE_NO`, `ADDRESS`, `ORDER_DATE`, `QUANTITY`) VALUES ('2', '2', 'Mona', '875451395', 'Rakshak Nagar', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`ORDER_ID`, `BOOK_ID`, `CUS_NAME`, `PHONE_NO`, `ADDRESS`, `ORDER_DATE`, `QUANTITY`) VALUES ('3', '3', 'Kavi', '7845127845', 'Rakshak Nagar Gold', '2016-11-08', '2');
INSERT INTO `shopping_cart`.`order_details` (`ORDER_ID`, `BOOK_ID`, `CUS_NAME`, `PHONE_NO`, `ADDRESS`, `ORDER_DATE`, `QUANTITY`) VALUES ('4', '4', 'Monalisa', '784512788', 'Bangalore', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`ORDER_ID`, `BOOK_ID`, `CUS_NAME`, `PHONE_NO`, `ADDRESS`, `ORDER_DATE`, `QUANTITY`) VALUES ('5', '5', 'Amol', '784578215', 'Wadganosheri', '2016-11-08', '3');
INSERT INTO `shopping_cart`.`order_details` (`ORDER_ID`, `BOOK_ID`, `CUS_NAME`, `PHONE_NO`, `ADDRESS`, `ORDER_DATE`, `QUANTITY`) VALUES ('6', '6', 'AMit', '78521868', 'Bangalore', '2016-11-08', '2');


INSERT INTO `shopping_cart`.`users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES ('Amit', 'Wagholi', 'amit.mishra369@gmail.com', '9673960407', 'mona9Dutta', '2016-11-08');
INSERT INTO `shopping_cart`.`users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES ('Hari', 'Chandan Nagar', 'hari39@rediffmail.com', '7845127421', 'Adam99@', '2016-11-08');
INSERT INTO `shopping_cart`.`users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES ('Monalisa', 'Rakshak Nagar', 'mona9@gmail.com', '9878454503', 'pinaki9@', '2016-11-08');
INSERT INTO `shopping_cart`.`users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES ('Narendra', 'Rajpath', 'narendra17@pmo.nic.in', '8877990011', 'Delhi9%', '2016-11-08');
INSERT INTO `shopping_cart`.`users` (`first_name`, `address`, `email`, `user_name`, `password`, `registration_date`) VALUES ('Kavita', 'Rakshak Nagar Gold', 'kavi23@gmail.com', '9878521402', 'Alia8&', '2016-11-08');
