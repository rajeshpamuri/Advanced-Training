package problemstatement3_1;
public abstract class Instrument {
	public abstract void play();
}
